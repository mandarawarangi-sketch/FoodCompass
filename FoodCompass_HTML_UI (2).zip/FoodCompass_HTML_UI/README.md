# FoodCompass Multi-Page HTML UI

Based on the IS20 FoodCompass proposal.

## Pages
- index.html — landing page / project overview
- products.html — product discovery, search and filters
- compare.html — product comparison
- lists.html — saved and shared shopping lists
- login.html — role-based demo login screen
- dashboard.html — customer dashboard
- product-owner.html — product owner dashboard
- retailer.html — retailer dashboard
- admin.html — platform administrator dashboard (overview, product submissions, link to category management)
- admin-categories.html — product category management (add, view, search, edit, delete unused)

## Technology
HTML5 + CSS3 + small vanilla JavaScript interactions.

The proposal specifies HTML/CSS for UI, JavaScript for client-side interactions/filtering, PHP for backend logic and MySQL for database management. This package is intentionally frontend-only and can be connected to PHP/MySQL later.

Source basis: IS20 proposal presentation, including FoodCompass capabilities, actors, functional requirements and technology choices.
